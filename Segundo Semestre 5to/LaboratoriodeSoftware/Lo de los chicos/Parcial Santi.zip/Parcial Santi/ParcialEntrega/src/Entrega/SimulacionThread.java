package Entrega;

public class SimulacionThread implements Runnable{
	private int id;
	private int[][] tablero;
	private int m;
	private int n;
	private int loops;
	
	
	
	public SimulacionThread(int id, int[][] tablero, int m, int n, int loops) {
		super();
		this.id = id;
		this.tablero = tablero;
		this.m = m;
		this.n = n;
		this.loops = loops;
	}

	private boolean tableroVivo(int[][] tablero, int m, int n) {
		boolean estado = false;
		mainloop:
		for (int i = 0; i < m; i++) {
			for (int j = 0; j < n; j++) {
				if(tablero[i][j] == 1) {
					estado = true;
					break mainloop;
				}
			}
		}
		return estado;
	}
	
	public void run() {
		GameOfLife.showGrid(this.tablero, m, n, "Comienzo del Thread " + this.id);
		try {
			for (int i = 0; i < loops; i++) {
				this.tablero = GameOfLife.nextGeneration(this.tablero, m, n);
				if (!this.tableroVivo(this.tablero, m, n)){
					throw new TableroMuertoException();
				}
			}
		} catch (TableroMuertoException ex) {
			System.out.println("Se corta el loop");
		}
		GameOfLife.showGrid(this.tablero, m, n, "Final del Thread " + this.id);
	}
	
}
