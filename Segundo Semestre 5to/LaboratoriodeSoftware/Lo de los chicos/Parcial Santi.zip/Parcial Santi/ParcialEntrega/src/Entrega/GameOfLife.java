package Entrega;

// A simple Java program to implement Game of Life
public class GameOfLife
{
	
	// Function to print next generation
	static int[][] nextGeneration(int grid[][], int m, int n)
	{
		int[][] future = new int[m][n];

		// Loop through every cell
		for (int row = 1; row < m - 1; row++)
		{
			for (int col = 1; col < n - 1; col++)
			{
				// finding no Of Neighbours that are alive
				int aliveNeighbours = 0;
				for (int i = -1; i <= 1; i++)
					for (int j = -1; j <= 1; j++)
						aliveNeighbours += grid[row + i][col + j];

				// The cell needs to be subtracted from
				// its neighbours as it was counted before
				aliveNeighbours -= grid[row][col];

				// Implementing the Rules of Life

				// Cell is lonely and dies
				if ((grid[row][col] == 1) && (aliveNeighbours < 2))
					future[row][col] = 0;

				// Cell dies due to over population
				else if ((grid[row][col] == 1) && (aliveNeighbours > 3))
					future[row][col] = 0;

				// A new cell is born
				else if ((grid[row][col] == 0) && (aliveNeighbours == 3))
					future[row][col] = 1;

				// Remains the same
				else
					future[row][col] = grid[row][col];
			}
			
		}

		return future;
	}
	
	public static  synchronized void  showGrid(int[][] grid,int m,int n,String title) {
		System.out.println(title);
		for (int i = 0; i < m; i++)
		{
			for (int j = 0; j < n; j++)
			{
				if (grid[i][j] == 0)
					System.out.print(".");
				else
					System.out.print("*");
			}
			System.out.println();
		}
		System.out.println();
	}
}