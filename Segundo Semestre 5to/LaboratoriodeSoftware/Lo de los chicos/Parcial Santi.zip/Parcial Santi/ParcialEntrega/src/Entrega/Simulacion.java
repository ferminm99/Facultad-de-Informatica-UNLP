package Entrega;

@Configuracion(m = 20, n = 20, cantSimulaciones = 5)
public class Simulacion {
	
	public Simulacion() {
		super();
	}

	@EstadoInicial
	public boolean getEstadoCelula() {
		double random = Math.random();
		if (random > 0.5) {
			return true;
		}
		return false;
	}
	
	@CantidadTurnos
	private int cantidadTurnos = 1;
	
}

