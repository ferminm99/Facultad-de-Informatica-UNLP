package Entrega;

public class JuegoDeLaVidaTest {

	public static void main(String[] args) {
		JuegoDeLaVida juego = new JuegoDeLaVida();
		juego.iniciar();
		
	}

}
