package Entrega;

import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;


public class JuegoDeLaVida {

	public JuegoDeLaVida() {
		super();
	}

	private int m;
	private int n;
	private int loops;
	private int cantSimulaciones;
	private Method metodoCelula = null;
	
	
	private void leerSimulacion(Simulacion simulacion) {
		try {
            Class myClass = simulacion.getClass();
            for(Annotation a : myClass.getAnnotations()){
                if(a.annotationType() == Configuracion.class){
                	Configuracion config = (Configuracion) a;
                	this.m = config.m();
                	this.n = config.n();
                	this.cantSimulaciones = config.cantSimulaciones();
                }
            }
            for(Method method : myClass.getDeclaredMethods()){
                for(Annotation an : method.getDeclaredAnnotations()){
                    if(an.annotationType() == EstadoInicial.class){
                    	this.metodoCelula = method;
                    }
                }
            }
            for(Field field : myClass.getDeclaredFields()) {
            	for(Annotation ann : field.getDeclaredAnnotations()){
                    if(ann.annotationType() == CantidadTurnos.class){
                    	field.setAccessible(true);
                    	loops = field.getInt(simulacion);
                    }
                }
            }
        } catch(Exception e) {
            e.printStackTrace();
        }
	}
	
	private List<SimulacionThread> crearSimulaciones(Simulacion simulacion){
		List<SimulacionThread> simulaciones = new ArrayList<SimulacionThread>();
		for (int i = 0; i < cantSimulaciones; i++) {
			//crear tablero
			int[][] tableroNuevo = new int[m][n];
			for (int j = 0; j < m; j++) {
				for (int j2 = 0; j2 < n; j2++) {
					try {
						boolean b = false;
						b = (boolean) metodoCelula.invoke(simulacion);      					
						if(b) {
							tableroNuevo[j][j2] = 1;
						} else {
							tableroNuevo[j][j2] = 0;
						}
					} catch (Exception e) {
						System.out.println("Error al invocar el metodo celula");
						tableroNuevo[j][j2] = 0;
					}
				}
			}
						
			//crear thread simulacion
			SimulacionThread s = new SimulacionThread(i, tableroNuevo, m, n, loops);
			simulaciones.add(s);			
		}
		return simulaciones;
	}
	
	
	public void iniciar() {
		
		//OBTENER PARAMETROS
		Simulacion simulacion = new Simulacion();
		this.leerSimulacion(simulacion);
		
		//CREAR RUNNEABLES
		List<SimulacionThread> simulaciones = this.crearSimulaciones(simulacion);
		
		//Encolarlos
		ExecutorService exec = Executors.newFixedThreadPool(cantSimulaciones);
		for (int i = 0; i < cantSimulaciones; i++) {
			exec.execute(simulaciones.get(i));
		}
		exec.shutdown();
		
	}
	
}
