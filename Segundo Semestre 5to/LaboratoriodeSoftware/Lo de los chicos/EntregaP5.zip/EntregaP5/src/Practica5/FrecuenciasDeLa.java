package Practica5;

public enum FrecuenciasDeLa {
	HZ440("Organizaci�n Internacional de Estandarizaci�n ISO 16."),
	HZ444("Afinaci�n de c�mara."),
	HZ446("Renacimiento."),
	HZ480("�rganos alemanes que tocaba Bach.");

	private String desc;
	FrecuenciasDeLa(String d) {
		this.desc = d;
	}
	
	
}
